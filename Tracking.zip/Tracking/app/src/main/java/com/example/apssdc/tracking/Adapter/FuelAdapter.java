package com.example.apssdc.tracking.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.apssdc.tracking.Data.FuelData;
import com.example.apssdc.tracking.Detail;
import com.example.apssdc.tracking.R;
import com.example.apssdc.tracking.Results;

import java.util.ArrayList;

public class FuelAdapter extends RecyclerView.Adapter<FuelAdapter.ViewHolder> {
    private ArrayList<FuelData> fuelDataArrayList;
    Context context;
    String[] data;
    Double slat, slon;
    ArrayList<Double> distance_array;
    ArrayList<Double> dlat;
    ArrayList<Double> dlon;

    public FuelAdapter(Results results, ArrayList<FuelData> fuelData, String[] data, ArrayList<Double> distance_array, Double slat, Double slon, ArrayList<Double> dlat, ArrayList<Double> dlon) {
        this.context = results;
        this.fuelDataArrayList = fuelData;
        this.data = data;
        this.distance_array = distance_array;
        this.slat = slat;
        this.slon = slon;
        this.dlat = dlat;
        this.dlon = dlon;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.vehiclelist, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull FuelAdapter.ViewHolder viewHolder, int i) {
        viewHolder.Name.setText(fuelDataArrayList.get(i).getBunkName());
        viewHolder.place.setText(distance_array.get(0).floatValue() + " Kms");
    }

    @Override
    public int getItemCount() {
        return fuelDataArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView Name, place;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            Name = itemView.findViewById(R.id.Name);
            place = itemView.findViewById(R.id.place);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            Intent detail = new Intent(context, Detail.class);
            detail.putExtra("fueldetails", fuelDataArrayList.get(getAdapterPosition()));
            detail.putExtra("fuel", true);
            detail.putExtra("slat", slat);
            detail.putExtra("slon", slon);
            detail.putExtra("dlat", dlat.get(getAdapterPosition()));
            detail.putExtra("dlon", dlon.get(getAdapterPosition()));
            context.startActivity(detail);

        }
    }
}
