package com.example.apssdc.tracking.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.apssdc.tracking.Data.VehicleData;
import com.example.apssdc.tracking.Detail;
import com.example.apssdc.tracking.R;
import com.example.apssdc.tracking.Results;

import java.util.ArrayList;

public class VehicleAdapter extends RecyclerView.Adapter<VehicleAdapter.ViewHolder> {
    private ArrayList<VehicleData> vehicleDataArrayList;
    Context context;
    String[] data;
    Double slat, slon;
    ArrayList<Double> distance_array;
    ArrayList<Double> dlat;
    ArrayList<Double> dlon;

    public VehicleAdapter(Results results, ArrayList<VehicleData> vehicleData, String[] data, ArrayList<Double> distance_array, Double slat, Double slon, ArrayList<Double> dlat, ArrayList<Double> dlon) {
        this.context = results;
        this.vehicleDataArrayList = vehicleData;
        this.data = data;
        this.distance_array = distance_array;
        this.slat = slat;
        this.slon = slon;
        this.dlat = dlat;
        this.dlon = dlon;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.vehiclelist, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        viewHolder.Name.setText(vehicleDataArrayList.get(i).getGarageName());
        /*for(int k=0;k<=i;k++){
             viewHolder.place.setText(distance_array.get(k).floatValue() + " Kms");
        }*/

        //Toast.makeText(context, ""+distance_array.get(0).floatValue(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public int getItemCount() {
        return vehicleDataArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView Name, place;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            Name = itemView.findViewById(R.id.Name);
            place = itemView.findViewById(R.id.place);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            Intent detail = new Intent(context, Detail.class);
            detail.putExtra("vehicledetails", vehicleDataArrayList.get(getAdapterPosition()));
            detail.putExtra("slat", slat);
            detail.putExtra("slon", slon);
            detail.putExtra("dlat", dlat.get(getAdapterPosition()));
            detail.putExtra("dlon", dlon.get(getAdapterPosition()));
            context.startActivity(detail);

        }
    }
}
