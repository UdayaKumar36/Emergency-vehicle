package com.example.apssdc.tracking.Fragments;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.apssdc.tracking.Adapter.DashBoard_pcodeAdapter;
import com.example.apssdc.tracking.Adapter.DashBoard_locAdapter;
import com.example.apssdc.tracking.Data.BunkData;
import com.example.apssdc.tracking.Data.MyData;
import com.example.apssdc.tracking.R;

import java.util.ArrayList;
import java.util.HashSet;


/**
 * A simple {@link Fragment} subclass.
 */
public class DashBoardFragment extends Fragment {


    RecyclerView dashrecycler;
    ArrayList<String> uniquepostalcode = new ArrayList<>();
    ArrayList<String> uniquelocation = new ArrayList<>();
    int sort = 0;

    public DashBoardFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_dash_board, container, false);
        dashrecycler = view.findViewById(R.id.dashrecycler);
        dashrecycler.setLayoutManager(new LinearLayoutManager(getContext()));
        dashrecycler.setItemAnimator(new DefaultItemAnimator());

        setHasOptionsMenu(true);
        RecyclerView.ItemDecoration itemDecoration = new
                DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL);
        dashrecycler.addItemDecoration(itemDecoration);
        dashrecycler.setHasFixedSize(true);


        HashSet<String> UniquePostalcode = new HashSet<>();
        HashSet<String> UniqueLocation = new HashSet<>();

        for (String item : MyData.postalcode) {
            if (!UniquePostalcode.contains(item)) {
                uniquepostalcode.add(item);
                UniquePostalcode.add(item);
            }
        }

        for (String item : BunkData.postalcode) {
            if (!UniquePostalcode.contains(item)) {
                uniquepostalcode.add(item);
                UniquePostalcode.add(item);
            }
        }


        for (String item : MyData.place) {
            if (!UniqueLocation.contains(item)) {
                uniquelocation.add(item);
                UniqueLocation.add(item);
            }
        }

        for (String item : BunkData.place) {
            if (!UniqueLocation.contains(item)) {
                uniquelocation.add(item);
                UniqueLocation.add(item);
            }
        }


        dashrecycler.setAdapter(new DashBoard_locAdapter(DashBoardFragment.this, uniquelocation));
        Toast.makeText(getContext(), "" + uniquelocation.size(), Toast.LENGTH_SHORT).show();

        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_detail, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_sort:
                showSortMenu(getActivity().findViewById(R.id.action_sort));
                return true;
            default:
                break;
        }
        return false;
    }

    private void showSortMenu(View actionView) {
        PopupMenu sortMenu = new PopupMenu(getContext(), actionView);
        sortMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @SuppressLint("NewApi")
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.pcode:
                        dashrecycler.setAdapter(new DashBoard_pcodeAdapter(DashBoardFragment.this, uniquepostalcode));
                        Toast.makeText(getContext(), "" + uniquepostalcode.size(), Toast.LENGTH_SHORT).show();
                        return true;

                    case R.id.loc:
                        dashrecycler.setAdapter(new DashBoard_locAdapter(DashBoardFragment.this, uniquelocation));
                        Toast.makeText(getContext(), "" + uniquelocation.size(), Toast.LENGTH_SHORT).show();
                        return true;

                    default:
                        return false;
                }
            }
        });
        MenuInflater inflater = sortMenu.getMenuInflater();
        inflater.inflate(R.menu.sort, sortMenu.getMenu());
        sortMenu.show();
    }
}
