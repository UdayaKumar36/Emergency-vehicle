package com.example.apssdc.tracking.Data;

public class BunkData {

    public static String[] postalcode = {"534201", "534201", "534202", "534202", "534201", "534202", "534201", "533107", "533101", "533107"
            , "533107", "533103", "533103", "530003", "530041", "530003",
            "530013", "530013", "530017"};


    public static String[] place = {"Bhimavaram", "Bhimavaram", "Bhimavaram", "Bhimavaram", "Bhimavaram", "Bhimavaram", "Bhimavaram"
            , "Rajahmundry", "Rajahmundry", "Rajahmundry", "Rajahmundry", "Rajahmundry", "Rajahmundry", "Visakhapatnam", "Visakhapatnam",
            "Visakhapatnam", "Visakhapatnam", "Visakhapatnam", "Visakhapatnam"};

    public static String[] BunkName = {"Barma Sheel Bharat Petrolium", "Reliance Petroleum Ltd", "Raos Fuel Station",
            "Indian Oil Petrol Pump", "Indian Oil Petrol Bunk", "Jaya SAI Filling Station",
            "Sree Rama Service Station", "Hp Petrol Pump", "Sri Lakshmi Agencies", "Hp Petrol Pump - M G Petro Agencies",
            "Sri Surya Prakash Service Station", "Reliance Petrol Pump", "Bhaskara Agencies", "Millenium Petrol Outlet",
            "Hpcl Petrol Pump - Lalitha Gowri Petroleum ", "Hpcl Millinium Outlet", "HP Auto Care Center", "S R Bar & Co",
            "Yogi Raghavendra Energy"};

    public static String[] BunkAddress = {"Main Road,", "Rs No.238/1,2,3 In Warde N Lock 8 Ts No 19, Gunupudi Village, Opposite Swc Godowns",
            "5-20, Palkolu Road,Veravasaram", "Juvvalapalem Road, Balusumoodi, Sivaraopeta",
            "D.no: 2-1-49, Bhimavaram Bazar, J P Road", " Undi Road, Narasimhapuram",
            "Near Kishore Theatre, P P Road, Sivaraopeta", "Kesavaram Road, Morampudi",
            "Kambala Peta, Near Kambala Tank", "Gajjaram", "Door No 70-3-1, Nh 5 Road, Lala Cheruvu, Beside Menaka Bar"
            , "Near Rtc Complex, Thadithota Road, Anand Nagar", "Door No 85-6-20, Morampudi Junction, Konerupeta", "Siripuram, Near Siripuram Junction"
            , "S/No: 180, Pardesipalem, Marikavalsa Village, Nh 16, Madhuravada,", "Siripuram, Opp Vuda Children Theatre",
            "52-14-77/a, Resapuvanipalem, Near Spencers Supermarket", "Maddilapalem, NH5 RD", "Main Road, Lawsons Bay Colony, Near Waltaire Depot "};

    public static String[] BunkTimings = {"9:30 am - 6:30 pm", "Open 24 Hrs", "Open 24 Hrs", "Open 24 Hrs", "Open 24 Hrs", "9:30 am - 9:30 pm"
            , "9:30 am - 9:30 pm", "Open 24 Hrs", "Open 24 Hrs", "5:00 am - 11:00 pm", "Open 24 Hrs", "Open 24 Hrs", "Open 24 Hrs", "Open 24 Hrs",
            "Open 24 Hrs", "7:00 am - 11:00 pm", "Open 24 Hrs", "Open 24 Hrs", "Open 24 Hrs"};

    public static String[] phonenumbers = {"8816234349", "9948522222", "8816286733", "8816222777", "8816222975", "8816226780", "9908684099",
            "8832442061", "9492882838", "9848013269", "8816286733", "9247011319", "9848228320", "8912551744", "9959586669", "8912551733 , 8912551744",
            "8912719755", "8912571717", "8912779099 , 8885935353"};
}
