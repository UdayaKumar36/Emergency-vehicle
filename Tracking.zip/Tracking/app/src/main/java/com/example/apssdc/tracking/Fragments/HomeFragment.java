package com.example.apssdc.tracking.Fragments;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.apssdc.tracking.Data.MyData;
import com.example.apssdc.tracking.MainActivity;
import com.example.apssdc.tracking.R;
import com.example.apssdc.tracking.Results;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

@SuppressLint("ValidFragment")
public class HomeFragment extends Fragment {

    private OnFragmentInteractionListener mListener;
    @InjectView(R.id.Datalayout)
    LinearLayout datalayout;
    @InjectView(R.id.vehiclelayout)
    LinearLayout vehiclelayout;
    @InjectView(R.id.fuellayout)
    LinearLayout fuellayout;
    @InjectView(R.id.state)
    EditText etstate;
    @InjectView(R.id.country)
    EditText etcountry;
    @InjectView(R.id.city)
    EditText etcity;
    @InjectView(R.id.address)
    EditText etaddress;
    @InjectView(R.id.postalcode)
    EditText etpostalcode;
    @InjectView(R.id.radiolocation)
    RadioGroup radioGroup;
    @InjectView(R.id.vehiclegroup)
    RadioGroup vehiclegroup;
    @InjectView(R.id.fuelgroup)
    RadioGroup fuelgroup;
    @InjectView(R.id.twowheeler)
    RadioButton twowheeler;
    @InjectView(R.id.fourwheeler)
    RadioButton fourwheeler;
    @InjectView(R.id.petrol)
    RadioButton petrol;
    @InjectView(R.id.diesel)
    RadioButton diesel;
    @InjectView(R.id.vehicle)
    CheckBox vehicle;
    @InjectView(R.id.fuel)
    CheckBox fuel;
    @InjectView(R.id.search)
    Button search;
    @InjectView(R.id.clear)
    Button clear;
    @InjectView(R.id.fuelimg)
    ImageView fuelimg;


    private String city, state, country, address, postalcode, vehicletype, fueltype;
    Context context;
    protected Boolean value = true;
    Double latitude, longitude;
    View view;

    @SuppressLint("ValidFragment")
    public HomeFragment(Context context, String country, String state, String city, String address, String postalcode,
                        Double longitude, Double latitude) {
        this.context = context;
        this.country = country;
        this.state = state;
        this.city = city;
        this.address = address;
        this.postalcode = postalcode;
        this.latitude = latitude;
        this.longitude = longitude;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        view = inflater.inflate(R.layout.fragment_home, container, false);
        getActivity().setTitle(R.string.title_home);

        ButterKnife.inject(this, view);


        search.setVisibility(View.GONE);
        RadioLocation();
        ProblemType();

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] search = new String[8];
                search[0] = vehicletype;
                search[1] = fueltype;
                search[2] = etpostalcode.getText().toString();
                search[3] = etaddress.getText().toString();
                search[4] = etcity.getText().toString();
                search[5] = String.valueOf(latitude);
                search[6] = String.valueOf(longitude);

                /*for (int i = 0; i < MyData.postalcode.length; i++) {
                    if (search[2].equalsIgnoreCase(MyData.postalcode[i])) {

                        break;
                    } else {
                        Toast.makeText(getContext(), "Enter pincode has No Details", Toast.LENGTH_SHORT).show();
                        break;
                    }
                }*/

                Intent sintent = new Intent(getContext(), Results.class);
                sintent.putExtra("search", search);
                getContext().startActivity(sintent);


            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //getActivity().finish();
            }
        });

        return view;
    }


    private void RadioLocation() {
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radiocurrent:
                        if (address == null) {
                          /*  if (value == true) {
                                value = false;
                                GPSALert();
                            }*/
                            datalayout.setVisibility(View.GONE);
                        } else {
                            datalayout.setVisibility(View.VISIBLE);
                            etcountry.setText(country);
                            etstate.setText(state);
                            etcity.setText(city);
                            etaddress.setText(address);
                            etpostalcode.setText(postalcode);
                        }

                        return;
                    case R.id.radiouser:
                        if (address == null) {
                            datalayout.setVisibility(View.VISIBLE);
                        } else {
                            etcountry.setText("");
                            etstate.setText("");
                            etcity.setText("");
                            etaddress.setText("");
                            etpostalcode.setText("");
                        }
                        etaddress.requestFocus();
                        return;

                }
            }
        });

    }

    private void GPSALert() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
        alertDialog.setTitle("GPS Settings");
        alertDialog.setMessage("Enable Location Provider! Go To Settings menu");
        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                getActivity().startActivity(intent);
            }
        });
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }

    private void ProblemType() {

        if (!vehicle.isChecked() && !fuel.isChecked()) {
            vehiclelayout.setVisibility(View.GONE);
            fuellayout.setVisibility(View.GONE);
        }


        vehicle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    vehiclelayout.setVisibility(View.VISIBLE);
                    vehicletype = twowheeler.getText().toString();
                    search.setVisibility(View.VISIBLE);
                    vehiclegroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(RadioGroup group, int checkedId) {
                            switch (checkedId) {
                                case R.id.twowheeler:
                                    vehicletype = twowheeler.getText().toString();
                                    break;
                                case R.id.fourwheeler:
                                    vehicletype = fourwheeler.getText().toString();
                                    break;

                            }
                        }
                    });

                } else {
                    vehiclegroup.clearCheck();
                    vehicletype = "";
                    if (fuel.isChecked()) {
                        vehiclelayout.setVisibility(View.GONE);
                    } else {
                        search.setVisibility(View.GONE);
                        vehiclelayout.setVisibility(View.GONE);
                    }

                }

            }
        });

        fuel.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    fuellayout.setVisibility(View.VISIBLE);
                    fueltype = petrol.getText().toString();
                    search.setVisibility(View.VISIBLE);
                    fuelgroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(RadioGroup group, int checkedId) {
                            switch (checkedId) {
                                case R.id.petrol:
                                    fueltype = petrol.getText().toString();
                                    break;
                                case R.id.diesel:
                                    fueltype = diesel.getText().toString();
                                    break;
                            }
                        }
                    });
                } else {
                    fuelgroup.clearCheck();
                    fueltype = "";
                    if (vehicle.isChecked()) {
                        fuellayout.setVisibility(View.GONE);
                    } else {
                        search.setVisibility(View.GONE);
                        fuellayout.setVisibility(View.GONE);
                    }
                }

            }
        });
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
