package com.example.apssdc.tracking.Data;

import android.os.Parcel;
import android.os.Parcelable;

public class VehicleData implements Parcelable {

    String place;
    String postalcode;
    String vehicletype;
    String GarageName;
    String GarageAddress;
    String GarageTimings;
    String PhoneNumbers;


    public static Creator<VehicleData> getCREATOR() {
        return CREATOR;
    }

    public VehicleData(String postalcode, String address, String garageName, String garageAddress, String garageTimings, String phoneNumbers) {

        this.postalcode = postalcode;
        this.place = address;
        this.vehicletype = vehicletype;
        GarageName = garageName;
        GarageAddress = garageAddress;
        GarageTimings = garageTimings;
        PhoneNumbers = phoneNumbers;
    }

    protected VehicleData(Parcel in) {
        place = in.readString();
        postalcode = in.readString();
        vehicletype = in.readString();
        GarageName = in.readString();
        GarageAddress = in.readString();
        GarageTimings = in.readString();
        PhoneNumbers = in.readString();
    }

    public static final Creator<VehicleData> CREATOR = new Creator<VehicleData>() {
        @Override
        public VehicleData createFromParcel(Parcel in) {
            return new VehicleData(in);
        }

        @Override
        public VehicleData[] newArray(int size) {
            return new VehicleData[size];
        }
    };

    public String getPlace() {
        return place;
    }

    public void setPlace(String address) {
        place = address;
    }

    public String getPostalcode() {
        return postalcode;
    }

    public void setPostalcode(String postalcode) {
        this.postalcode = postalcode;
    }

    public String getVehicletype() {
        return vehicletype;
    }

    public void setVehicletype(String vehicletype) {
        this.vehicletype = vehicletype;
    }

    public String getGarageName() {

        return GarageName;
    }

    public void setGarageName(String garageName) {
        GarageName = garageName;
    }

    public String getGarageAddress() {
        return GarageAddress;
    }

    public void setGarageAddress(String garageAddress) {
        GarageAddress = garageAddress;
    }

    public String getGarageTimings() {
        return GarageTimings;
    }

    public void setGarageTimings(String garageTimings) {
        GarageTimings = garageTimings;
    }

    public String getPhoneNumbers() {
        return PhoneNumbers;
    }

    public void setPhoneNumbers(String phoneNumbers) {
        PhoneNumbers = phoneNumbers;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(place);
        dest.writeString(postalcode);
        dest.writeString(vehicletype);
        dest.writeString(GarageName);
        dest.writeString(GarageAddress);
        dest.writeString(GarageTimings);
        dest.writeString(PhoneNumbers);
    }
}
