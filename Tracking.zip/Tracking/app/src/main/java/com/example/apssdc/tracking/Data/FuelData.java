package com.example.apssdc.tracking.Data;

import android.os.Parcel;
import android.os.Parcelable;

public class FuelData implements Parcelable {

    String place;
    String postalcode;
    String BunkName;
    String BunkAddress;
    String BunkTimings;
    String PhoneNumbers;

    public FuelData(Parcel in) {
        place = in.readString();
        postalcode = in.readString();
        BunkName = in.readString();
        BunkAddress = in.readString();
        BunkTimings = in.readString();
        PhoneNumbers = in.readString();
    }

    public static final Creator<FuelData> CREATOR = new Creator<FuelData>() {
        @Override
        public FuelData createFromParcel(Parcel in) {
            return new FuelData(in);
        }

        @Override
        public FuelData[] newArray(int size) {
            return new FuelData[size];
        }
    };

    public FuelData(String place, String postalcode, String bunkName, String bunkAddress, String bunkTimings, String phoneNumbers) {
        this.place = place;
        this.postalcode = postalcode;
        BunkName = bunkName;
        BunkAddress = bunkAddress;
        BunkTimings = bunkTimings;
        PhoneNumbers = phoneNumbers;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(place);
        dest.writeString(postalcode);
        dest.writeString(BunkName);
        dest.writeString(BunkAddress);
        dest.writeString(BunkTimings);
        dest.writeString(PhoneNumbers);
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getPostalcode() {
        return postalcode;
    }

    public void setPostalcode(String postalcode) {
        this.postalcode = postalcode;
    }

    public String getBunkName() {
        return BunkName;
    }

    public void setBunkName(String bunkName) {
        BunkName = bunkName;
    }

    public String getBunkAddress() {
        return BunkAddress;
    }

    public void setBunkAddress(String bunkAddress) {
        BunkAddress = bunkAddress;
    }

    public String getBunkTimings() {
        return BunkTimings;
    }

    public void setBunkTimings(String bunkTimings) {
        BunkTimings = bunkTimings;
    }

    public String getPhoneNumbers() {
        return PhoneNumbers;
    }

    public void setPhoneNumbers(String phoneNumbers) {
        PhoneNumbers = phoneNumbers;
    }
}
