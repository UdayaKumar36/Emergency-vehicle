package com.example.apssdc.tracking.Data;

import com.example.apssdc.tracking.R;

public class MyData {

    public static String[] postalcode = {"534201", "534201", "534201", "534201", "534201", "534202", "534204", "534202", "534202", "534202",
            "533101", "533102", "533105", "533101", "533103", "533103", "530003", "530003", "530009", "530013", "530026", "530016", "530027"};


    public static String[] place = {"Bhimavaram", "Bhimavaram", "Bhimavaram", "Bhimavaram", "Bhimavaram", "Chinnamiram", "Chinnamiram",
            "Bhimavaram", "Bhimavaram", "Bhimavaram", "Rajahmundry", "Rajahmundry", "Rajahmundry", "Rajahmundry",
            "Rajahmundry", "Rajahmundry", "Visakhapatnam", "Visakhapatnam", "Visakhapatnam", "Visakhapatnam", "Visakhapatnam", "Visakhapatnam",
            "Visakhapatnam"};


    public static String[] Garagename = {"Varun Auto Riders", "Tata Motors", "Kodandarama Auto Garage", "Sri Raghavendraswamy Auto Works",
            "Bismillah Garage", "Naga Lakshmi Motor Mechanic Works", "Yamini Mechanics",
            "Sri Surya Auto Gaurage", "Sri Sathya Surya Klutch & Break Works", "Sai Sri Motor Mechanic Works",
            "Car And Motor Mechanics and Tinkaring Works", "Rajesh Mechanic Works",
            "Vijaya Durga Mechanical works 4 wheels", "Shiva Durga Bike Mechanic Works",
            "Rafi Car Mechanic", "Sri Vijaya Durga Scooter Mechanic Works",
            "Gluttons Garage", "Varun Motors Pvt Ltd (Workshop) ", "Siva Sankar Motors", "Vikas Automobiles", "Vizag Auto Services",
            "Sri Lakshmi E Automobile", "BURAKH Bike Works"};


    public static String[] GarageAddress = {"D-No:7-234/A Costal Tyre Retrading Side Road,Undi Bypass Road", "Undi Road",
            "Kodandarama Complex,ICICI Bank Backside,J.P Road(Beside Chandrika Restaurant)",
            "27-7-154,Dnr College Road(Beside Rajiv Gandhi Statue",
            "Shop no:4,Municipal Complex,PP Road,Somavaram(Near Over Bridge)",
            "Opposite S.R.K.R Engineering", "Juvvalapalem Road,Opposite Petrol Pump",
            "Undi Rd, Narasimhapuram", "Opposite. Hero Honda Show Room, Undi Road",
            "Opposite. Jnarada Eye Hospital, Town Station Road", "Tadithota",
            "D.No. 64-34-2/3 Opposite. Sivilayam Temple Quary Market", "Opposite SBI Bank, Lalacheruvu",
            "D. No. 26-3-24, Opp. Hotel Anand Regency Pandiri Hall, Exide Battery Shop",
            "RTO Office Road, Lala Cheruvu", "D. No. 36-36-12, VT College Road, Innespeta",
            "D.No. 7-5-182, Beside Aqua Sports Complex, Kirlampudi, Aqua Sports Complex", "58/2 Block No 5, Siripuram,Opposite Andhra University Balaji Nagar ",
            "Door No A-17 & B-4, 43-9-141Door No A-17 & B-4, 43-9-14Door No A-17 & B-4, 43-9-1411, Airport, Opposite Kendriya Vidyalala, Near Industrial Estate "
            , "Door No 53-23-10, NH 5, Maddilapalem, Near Kinnera Theater", "Block B, Plot No 18, Main Raod, Gajuwaka, Beside Bhvp Lane",
            "#43-9-131, TSN COLONY, Main Road, Dondaparthy, Near Yamaha show room", "Door No, RRV Puram, Gopalapatnam, Opp SVLN College "};


    public static String[] GarageTimings = {"9:30 am - 6:30 pm", "9:30 am - 6:00 pm", "9:30 am - 8:00 pm", "9:00 am - 9:30 pm",
            "9:00 am - 2:00 pm,4:00 pm - 9:00 pm", "9am–9pm", "9am–9pm", "Open 24 hours", "9am–8pm",
            "9am–8pm", "10am–7pm", "8am–9pm", "Timings are Not Available", "9am–9pm", "9:30am–9pm",
            "8:30am–9pm", "9:00 am - 9:00 pm", "Open 24 hours", "9:00 am - 6:30 pm", "Open 24 hours", "Open 24 hours", "9:30 am - 8:30 pm",
            "9am–9pm"};


    public static String[] phonenumbers = {"9848155263,9848112489", "08816-223513", "9951497677", "9948295778", "9849158833", "9948342299",
            "9866954014", "0", "98482 06568", "97052 62999", "96522 99226", "94411 78471",
            "91339 39636", "99499 29025", "94908 26383", "98499 50023", "8912564688 , 7702368884", "8912567968", "8912555591 ,8912555592",
            "8912701837", "8912519663", "9966499166,8885238899","9949147089"};

}
