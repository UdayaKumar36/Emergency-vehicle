package com.example.apssdc.tracking;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.apssdc.tracking.Data.FuelData;
import com.example.apssdc.tracking.Data.MyData;
import com.example.apssdc.tracking.Data.VehicleData;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Detail extends AppCompatActivity {

    int next, prev;
    Toolbar toolbar;
    Spinner dropdown;
    TextView possessordetails, time, addressdetails, contactdetails;
    ImageView getdirectiions;

    double slat, slon, dlat, dlon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        possessordetails = findViewById(R.id.possessordetails);
        time = findViewById(R.id.time);
        getdirectiions = findViewById(R.id.getdirections);
        addressdetails = findViewById(R.id.addressdetails);
        contactdetails = findViewById(R.id.contactdetails);


        final VehicleData vehicleData = getIntent().getParcelableExtra("vehicledetails");
        slat = getIntent().getDoubleExtra("slat", 0);
        slon = getIntent().getDoubleExtra("slon", 0);
        dlat = getIntent().getDoubleExtra("dlat", slat);
        dlon = getIntent().getDoubleExtra("dlon", slon);

        final FuelData fuelData = getIntent().getParcelableExtra("fueldetails");
        Boolean val = getIntent().getBooleanExtra("fuel", false);

        dropdown = findViewById(R.id.spinner1);

        Date_day_format(vehicleData, fuelData, val);
        getdirectiions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapsDirect();
            }
        });

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    private void Date_day_format(VehicleData vehicleData, FuelData fuelData, Boolean val) {
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
        Date d = new Date();
        final String dayOfTheWeek = sdf.format(d);
        String[] items = new String[]{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        List<String> day = new ArrayList<String>();

        for (int i = 0; i < items.length; i++) {
            if (dayOfTheWeek.equals(items[i])) {
                next = i;
                prev = i;
                day.add(items[i]);
            }
        }
        for (int k = next + 1; k < items.length; k++) {
            day.add(items[k]);
        }
        for (int k = 0; k <= prev - 1; k++) {
            day.add(items[k]);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, day);
        dropdown.setAdapter(adapter);


        if (!val) {
            Vehicledetails(vehicleData, day);

        } else {
            Fueldetails(fuelData, day);
        }
    }

    private void MapsDirect() {
        Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                Uri.parse("http://maps.google.com/maps?saddr=" + slat + "," + slon + "&daddr=" + dlat + "," + dlon));
        startActivity(intent);
    }


    private void Vehicledetails(final VehicleData vehicleData, final List<String> day) {
        toolbar.setTitle(vehicleData.getGarageName());
        addressdetails.setText(vehicleData.getGarageAddress() + " " + vehicleData.getPlace() + " " + vehicleData.getPostalcode());
        contactdetails.setText(vehicleData.getPhoneNumbers());
        AdapterView.OnItemSelectedListener timinglistener = new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> spinner, View container,
                                       int position, long id) {
                if (day.get(position).equals("Sunday")) {
                    time.setText("Closed ");
                } else {
                    time.setText(vehicleData.getGarageTimings());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        };
        dropdown.setOnItemSelectedListener(timinglistener);
    }

    private void Fueldetails(final FuelData fuelData, final List<String> day) {
        toolbar.setTitle(fuelData.getBunkName());
        addressdetails.setText(fuelData.getBunkAddress() + " " + fuelData.getPlace() + " " + fuelData.getPostalcode());
        contactdetails.setText(fuelData.getPhoneNumbers());
        AdapterView.OnItemSelectedListener timinglistener = new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> spinner, View container,
                                       int position, long id) {
                if (day.get(position).equals("Sunday") && !(fuelData.getBunkTimings().equals("Open 24 Hrs"))) {
                    time.setText("Closed ");
                } else {
                    time.setText(fuelData.getBunkTimings());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        };
        dropdown.setOnItemSelectedListener(timinglistener);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}
