package com.example.apssdc.tracking.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.apssdc.tracking.Fragments.DashBoardFragment;
import com.example.apssdc.tracking.R;

import java.util.ArrayList;

public class DashBoard_pcodeAdapter extends RecyclerView.Adapter<DashBoard_pcodeAdapter.ViewHolder> {
    Context context;
    ArrayList<String> postal;


    public DashBoard_pcodeAdapter(DashBoardFragment dashBoardFragment, ArrayList<String> uniquepostalcode) {
        this.context = dashBoardFragment.getContext();
        this.postal = uniquepostalcode;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.dashboard_list, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        viewHolder.postal_code.setText(postal.get(i));
        viewHolder.location.setVisibility(View.GONE);

    }

    @Override
    public int getItemCount() {
        return postal.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView postal_code;
        LinearLayout location;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            location = itemView.findViewById(R.id.location);
            postal_code = itemView.findViewById(R.id.postal_code);
        }

    }
}
