package com.example.apssdc.tracking;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.apssdc.tracking.Adapter.FuelAdapter;
import com.example.apssdc.tracking.Adapter.VehicleAdapter;
import com.example.apssdc.tracking.Data.BunkData;
import com.example.apssdc.tracking.Data.FuelData;
import com.example.apssdc.tracking.Data.MyData;
import com.example.apssdc.tracking.Data.VehicleData;

import java.util.ArrayList;

public class Results extends AppCompatActivity {

    RecyclerView vehilcerecylcer;
    String[] data;
    private static ArrayList<VehicleData> vehicleData;
    private static ArrayList<FuelData> fuelData;
    ArrayList<Double> distance_array = new ArrayList<>();
    ArrayList<Double> dlat = new ArrayList<>();
    ArrayList<Double> dlon = new ArrayList<>();
    public Double currentlatitude, currentlongitude, destinationlatitude, destinationlongitude;
    Double distance;
    public boolean type = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        vehilcerecylcer = findViewById(R.id.vehiclerecycler);
        vehilcerecylcer.setLayoutManager(new LinearLayoutManager(this));
        vehilcerecylcer.setItemAnimator(new DefaultItemAnimator());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        data = getIntent().getStringArrayExtra("search");

        if (data[0] == null) {
            data[0] = "Two_Wheeler";
        }

        Filtering();

        RecyclerView.ItemDecoration itemDecoration = new
                DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        vehilcerecylcer.addItemDecoration(itemDecoration);
        vehilcerecylcer.setHasFixedSize(true);
    }

    private void Filtering() {
        if (data[0].equalsIgnoreCase("Two Wheeler") || data[0].equalsIgnoreCase("Four Wheeler")) {
            vehicleData = new ArrayList<>();
            for (int i = 0; i < MyData.postalcode.length; i++) {
                if (data[2].equalsIgnoreCase(MyData.postalcode[i])) {
                    vehicleData.add(new VehicleData(
                            MyData.postalcode[i],
                            MyData.place[i],
                            MyData.Garagename[i],
                            MyData.GarageAddress[i],
                            MyData.GarageTimings[i],
                            MyData.phonenumbers[i]
                    ));
                }
                if (type) {
                    type = true;
                } else {
                    type = false;
                    Toast.makeText(this, "Not Available data", Toast.LENGTH_SHORT).show();
                }
            }

            for (int i = 0; i < vehicleData.size(); i++) {
                GeocodingLocation locationAddress = new GeocodingLocation();
                locationAddress.getAddressFromLocation(vehicleData.get(i).getGarageAddress(),
                        getApplicationContext(), new GeocoderHandler());
                setTitle(vehicleData.get(i).getPlace());
            }

        } else if (data[1].equalsIgnoreCase("Petrol") || data[1].equalsIgnoreCase("Diesel")) {
            fuelData = new ArrayList<>();
            Toast.makeText(this, "" + BunkData.postalcode.length, Toast.LENGTH_SHORT).show();
            for (int i = 0; i < BunkData.postalcode.length; i++) {
                if (data[2].equalsIgnoreCase(BunkData.postalcode[i])) {
                    fuelData.add(new FuelData(
                            BunkData.postalcode[i],
                            BunkData.place[i],
                            BunkData.BunkName[i],
                            BunkData.BunkAddress[i],
                            BunkData.BunkTimings[i],
                            BunkData.phonenumbers[i]

                    ));
                }
            }
            if (type) {
                type = false;
            } else {
                type = true;
            }
            for (int i = 0; i < fuelData.size(); i++) {
                GeocodingLocation locationAddress = new GeocodingLocation();
                locationAddress.getAddressFromLocation(fuelData.get(i).getBunkAddress(),
                        getApplicationContext(), new GeocoderHandler());
                setTitle(fuelData.get(i).getPlace());
            }
        } else {
            Toast.makeText(this, "No Data Available", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    public class GeocoderHandler extends Handler {
        @Override
        public void handleMessage(Message message) {

            switch (message.what) {
                case 1:
                    Bundle bundle = message.getData();
                    destinationlatitude = bundle.getDouble("la");
                    destinationlongitude = bundle.getDouble("lo");
                    //Toast.makeText(Results.this, "Latitude:" + destinationlatitude, Toast.LENGTH_SHORT).show();
                    //Toast.makeText(Results.this, "Longitude" + destinationlongitude, Toast.LENGTH_SHORT).show();
                    break;
                default:
                    destinationlatitude = null;
                    destinationlongitude = null;
            }
            currentlatitude = Double.valueOf(data[5]);
            currentlongitude = Double.valueOf(data[6]);

            distance(currentlatitude, currentlongitude, destinationlatitude, destinationlongitude);
            if (type) {
                if (vehicleData.size() != 0) {
                    vehilcerecylcer.setAdapter(new VehicleAdapter(Results.this, vehicleData, data, distance_array, currentlatitude, currentlongitude, dlat, dlon));
                    Toast.makeText(Results.this, "Distance :" + distance_array, Toast.LENGTH_SHORT).show();
                }
            } else {
                vehilcerecylcer.setAdapter(new FuelAdapter(Results.this, fuelData, data, distance_array, currentlatitude, currentlongitude, dlat, dlon));
                Toast.makeText(Results.this, "Distance :" + distance_array, Toast.LENGTH_SHORT).show();
            }

        }
    }

    public void distance(Double currentlatitude, Double currentlongitude, Double destinationlatitude, Double destinationlongitude) {
        double earthRadius = 3958.75;

        dlat.add(destinationlatitude);
        dlon.add(destinationlongitude);
        double dLat = Math.toRadians(currentlatitude - destinationlatitude);
        double dLng = Math.toRadians(currentlongitude - destinationlongitude);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(destinationlatitude)) * Math.cos(Math.toRadians(currentlatitude)) *
                        Math.sin(dLng / 2) * Math.sin(dLng / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        distance = earthRadius * c;
        distance_array.add(distance);

    }

}
